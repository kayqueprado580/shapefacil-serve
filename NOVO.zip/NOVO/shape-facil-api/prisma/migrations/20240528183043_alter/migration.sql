-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_dieta" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioID" INTEGER,
    "alunoID" INTEGER,
    "nutricionistaID" INTEGER,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "periodo" TEXT NOT NULL,
    "json" TEXT NOT NULL,
    "totalCalorias" TEXT,
    "totalProteinas" TEXT,
    "totalGordura" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_dieta" ("alunoID", "createdAt", "descricao", "id", "json", "nome", "nutricionistaID", "periodo", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioID") SELECT "alunoID", "createdAt", "descricao", "id", "json", "nome", "nutricionistaID", "periodo", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioID" FROM "dieta";
DROP TABLE "dieta";
ALTER TABLE "new_dieta" RENAME TO "dieta";
PRAGMA foreign_key_check("dieta");
PRAGMA foreign_keys=ON;
