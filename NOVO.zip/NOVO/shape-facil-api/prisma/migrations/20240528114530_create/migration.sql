-- CreateTable
CREATE TABLE "usuario" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "uid" TEXT NOT NULL,
    "nome" TEXT,
    "contato" TEXT,
    "documento" TEXT,
    "perfil" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "usuario" TEXT NOT NULL,
    "senha" TEXT NOT NULL,
    "isAdmnistrador" BOOLEAN NOT NULL DEFAULT false,
    "isNutricionista" BOOLEAN NOT NULL DEFAULT false,
    "isTreinador" BOOLEAN NOT NULL DEFAULT false,
    "isAluno" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "perfil_acesso" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioID" INTEGER NOT NULL,
    "perfil" TEXT NOT NULL,
    "acessoJson" TEXT NOT NULL,
    "createdAtUser" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "perfil_acesso_usuarioID_fkey" FOREIGN KEY ("usuarioID") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);

-- CreateTable
CREATE TABLE "historico_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "alunoID" INTEGER NOT NULL,
    "usuarioID" INTEGER,
    "treinadorID" INTEGER,
    "nutricionistaID" INTEGER,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "dieta" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioID" INTEGER NOT NULL,
    "alunoID" INTEGER,
    "nutricionistaID" INTEGER,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "periodo" TEXT NOT NULL,
    "json" TEXT NOT NULL,
    "totalCalorias" TEXT,
    "totalProteinas" TEXT,
    "totalGordura" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "treino" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioID" INTEGER NOT NULL,
    "alunoID" INTEGER,
    "treinadorID" INTEGER,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "PeriodoTreino" TEXT NOT NULL,
    "json" TEXT NOT NULL,
    "intensidade" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateTable
CREATE TABLE "avaliacao" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioID" INTEGER NOT NULL,
    "alunoID" INTEGER,
    "treinadorID" INTEGER,
    "nutricionistaID" INTEGER,
    "dietaID" INTEGER,
    "treinoID" INTEGER,
    "nome" TEXT NOT NULL,
    "tipo" TEXT,
    "nota" INTEGER NOT NULL,
    "descricao" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "usuario_uid_key" ON "usuario"("uid");

-- CreateIndex
CREATE UNIQUE INDEX "usuario_email_key" ON "usuario"("email");

-- CreateIndex
CREATE UNIQUE INDEX "usuario_usuario_key" ON "usuario"("usuario");

-- CreateIndex
CREATE UNIQUE INDEX "perfil_acesso_usuarioID_key" ON "perfil_acesso"("usuarioID");
