import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from './constants';
import { PrismaService } from '../lib/prisma.service';
import { AuthService } from './auth.service';
import { AuthController } from './auth.controller';
import { UsuarioService } from '../usuarios/usuarios.service';
import { UsuariosModule } from '../usuarios/usuarios.module';
import { PerfilService } from '../perfil/perfil.service';
import { HistoricoAlunoService } from 'src/historicos/historico.services';
import { DietaService } from 'src/dieta/dieta.service';

@Module({
  imports: [
    UsuariosModule,
    JwtModule.register({
      global: true,
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '300000s' },
    }),
  ],
  providers: [
    AuthService,
    UsuarioService,
    PrismaService,
    PerfilService,
    HistoricoAlunoService,
    DietaService,
  ],
  controllers: [AuthController],
  exports: [AuthService],
})
export class AuthModule {}
