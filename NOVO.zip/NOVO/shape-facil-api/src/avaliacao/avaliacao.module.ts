import { HistoricoAlunoController } from './historico.controller';
import { HistoricoAlunoService } from './historico.services';
import { Module } from '@nestjs/common';
import { PrismaService } from '../lib/prisma.service';

@Module({
  imports: [],
  controllers: [HistoricoAlunoController],
  providers: [HistoricoAlunoService, PrismaService],
  exports: [HistoricoAlunoService],
})
export class HistoricoModule {}
