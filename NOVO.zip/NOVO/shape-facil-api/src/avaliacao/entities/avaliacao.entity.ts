export class HistoricoAluno {
  id?: number;
  alunoID: number;
  usuarioID?: number;
  treinadorID?: number;
  nutricionistaID?: number;
  peso?: string;
  altura?: string;
  porcGordura?: string;
  porcMassaMagra?: string;
  medidas?: string;
  dataAvaliacao?: Date;
}
