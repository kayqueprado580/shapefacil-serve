import { HistoricoAluno } from '../entities/historico.entity';
import { IsOptional } from 'class-validator';

export class HistoricoAlunoCreateDTO extends HistoricoAluno {
  alunoID: number;
  @IsOptional()
  usuarioID?: number;
  @IsOptional()
  treinadorID?: number;
  @IsOptional()
  nutricionistaID?: number;
  @IsOptional()
  peso?: string;
  @IsOptional()
  altura?: string;
  @IsOptional()
  porcGordura?: string;
  @IsOptional()
  porcMassaMagra?: string;
  @IsOptional()
  medidas?: string;
  @IsOptional()
  dataAvaliacao?: Date;
}
