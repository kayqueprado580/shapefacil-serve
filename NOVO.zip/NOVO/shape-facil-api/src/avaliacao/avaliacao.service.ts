import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../lib/prisma.service';
import { Prisma } from '@prisma/client';
import { HistoricoAluno } from './entities/historico.entity';
import { HistoricoAlunoCreateDTO } from './dto/historicoCreate.dto';
import { Usuario } from 'src/usuarios/entities/usuario.entity';
import { HistoricoAlunoEditDTO } from './dto/historicoEdit.dto';
// import { checkIfExists } from '../util/database.utils';
// import { hasChanged } from '../util/change-detector.utils';

@Injectable()
export class HistoricoAlunoService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(
    skip: string,
    take: string,
    orderBy: string,
    // usuarioID: number,
  ) {
    const sk = parseInt(skip, 10);
    const tk = parseInt(take, 10);

    const data: HistoricoAluno[] = await this.prisma.historicoAluno.findMany({
      skip: sk ? sk : 0,
      take: tk ? tk : 20,
      orderBy: {
        createdAt: orderBy
          ? orderBy.toLowerCase() === 'asc'
            ? 'asc'
            : 'desc'
          : 'desc',
      },
      where: {},
    });

    return data;
  }

  async findOneById(id: number) {
    const data: HistoricoAluno =
      await this.prisma.historicoAluno.findUniqueOrThrow({
        where: {
          id: id,
        },
      });
    return data;
  }

  async create(
    historicoDTO: HistoricoAlunoCreateDTO,
    idUsuario: number,
  ): Promise<HistoricoAlunoCreateDTO> {
    const data: Prisma.HistoricoAlunoCreateInput = {
      ...historicoDTO,
      usuarioID: idUsuario,
      dataAvaliacao: new Date(),
    };
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id: idUsuario },
    });
    if (usuario.perfil.toLocaleLowerCase() === 'administrador')
      return await this.prisma.historicoAluno.create({ data });
    else throw new BadRequestException('Sem permissão...');
  }

  async remove(idRemove: number, idUsuario: number) {
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id: idUsuario },
    });

    if (usuario.perfil.toLocaleLowerCase() === 'administrador') {
      return await this.prisma.historicoAluno.delete({
        where: {
          id: idRemove,
        },
      });
    } else throw new BadRequestException('Sem permissão...');
  }

  async update(
    idUpdated: number,
    historicoAlunoDTO: HistoricoAlunoEditDTO,
    idUsuario: number,
  ): Promise<HistoricoAlunoEditDTO> {
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id: idUsuario },
    });

    if (usuario.perfil.toLocaleLowerCase() === 'administrador') {
      const data: Prisma.HistoricoAlunoUpdateInput = {
        ...historicoAlunoDTO,
      };

      const updated = await this.prisma.historicoAluno.update({
        data,
        where: {
          id: idUpdated,
        },
      });
      return updated;
    } else throw new BadRequestException('Sem permissão...');
  }
}
