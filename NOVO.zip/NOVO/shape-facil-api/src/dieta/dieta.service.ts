import { Injectable, BadRequestException } from '@nestjs/common';
import { PrismaService } from '../lib/prisma.service';
import { Prisma } from '@prisma/client';
import { Usuario } from 'src/usuarios/entities/usuario.entity';
import { Dieta } from './entities/dieta.entity';
import { DietaCreateDTO } from './dto/dietaCreate.dto';
import { DietaEditDTO } from './dto/dietaEdit.dto';

@Injectable()
export class DietaService {
  constructor(private readonly prisma: PrismaService) {}

  async findAll(skip: string, take: string, orderBy: string) {
    const sk = parseInt(skip, 10);
    const tk = parseInt(take, 10);

    const data: Dieta[] = await this.prisma.dieta.findMany({
      skip: sk ? sk : 0,
      take: tk ? tk : 20,
      orderBy: {
        createdAt: orderBy
          ? orderBy.toLowerCase() === 'asc'
            ? 'asc'
            : 'desc'
          : 'desc',
      },
      where: {},
    });

    return data;
  }

  async findOneById(id: number) {
    const data: Dieta = await this.prisma.dieta.findUniqueOrThrow({
      where: {
        id: id,
      },
    });
    return data;
  }

  async create(
    bodyDTO: DietaCreateDTO,
    idUsuario: number,
  ): Promise<DietaCreateDTO> {
    const data: Prisma.DietaCreateInput = {
      ...bodyDTO,
      usuarioID: idUsuario,
      json: JSON.stringify(bodyDTO.json),
    };
    const isValid = await this.checkPermissions(idUsuario);
    if (isValid) return await this.prisma.dieta.create({ data });
    else throw new BadRequestException('Sem permissão...');
  }

  async remove(idRemove: number, idUsuario: number) {
    const isValid = await this.checkPermissions(idUsuario);
    if (isValid) {
      return await this.prisma.dieta.delete({
        where: {
          id: idRemove,
        },
      });
    } else throw new BadRequestException('Sem permissão...');
  }

  async update(
    idUpdated: number,
    bodyDTO: DietaEditDTO,
    idUsuario: number,
  ): Promise<DietaEditDTO> {
    const isValid = await this.checkPermissions(idUsuario);
    if (isValid) {
      const data: Prisma.DietaUpdateInput = {
        ...bodyDTO,
        usuarioID: idUsuario,
        json: JSON.stringify(bodyDTO.json),
      };
      const updated = await this.prisma.dieta.update({
        data,
        where: {
          id: idUpdated,
        },
      });
      return updated;
    } else throw new BadRequestException('Sem permissão...');
  }

  async checkPermissions(idUsuario: number): Promise<boolean> {
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id: idUsuario },
    });

    const perfil = usuario.perfil.toLocaleLowerCase();
    const isAuthorized =
      perfil === 'administrador' || perfil === 'nutricionista';

    return isAuthorized;
  }
}
