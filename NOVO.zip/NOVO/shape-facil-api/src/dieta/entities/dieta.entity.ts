export class Dieta {
  id?: number;
  usuarioID?: number;
  alunoID?: number;
  nutricionistaID?: number;
  nome: string;
  descricao?: string;
  tipo: string;
  periodo: string;
  json: string;
  totalCalorias?: string;
  totalProteinas?: string;
  totalGordura?: string;
}
