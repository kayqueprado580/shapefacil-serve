import {
  Controller,
  Get,
  Req,
  Param,
  HttpException,
  HttpStatus,
  Query,
  Post,
  Body,
  Delete,
  Patch,
  UseGuards,
} from '@nestjs/common';
import { AuthGuard } from '../auth/auth.guard';
import { DietaService } from './dieta.service';
import { DietaCreateDTO } from './dto/dietaCreate.dto';
import { DietaEditDTO } from './dto/dietaEdit.dto';

@Controller('dieta-aluno')
export class DietaController {
  constructor(private readonly dietaService: DietaService) {}

  @UseGuards(AuthGuard)
  @Get()
  async findAll(
    @Query('skip') skip: string,
    @Query('take') take: string,
    @Query('orderBy') orderBy: string,
  ) {
    try {
      return await this.dietaService.findAll(skip, take, orderBy);
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.INTERNAL_SERVER_ERROR,
          error: error.message,
        },
        HttpStatus.INTERNAL_SERVER_ERROR,
        {
          cause: error,
        },
      );
    }
  }

  @UseGuards(AuthGuard)
  @Get(':id')
  async findOne(@Param('id') id: string) {
    try {
      return await this.dietaService.findOneById(+id);
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.NOT_FOUND,
          error: error.message,
        },
        HttpStatus.NOT_FOUND,
        {
          cause: error,
        },
      );
    }
  }

  @UseGuards(AuthGuard)
  @Post()
  async create(@Body() data: DietaCreateDTO, @Req() req: any) {
    const id = parseInt(req.user.sub, 10);
    try {
      return await this.dietaService.create(data, id);
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.FORBIDDEN,
          error: error.message,
        },
        HttpStatus.FORBIDDEN,
        {
          cause: error,
        },
      );
    }
  }

  @UseGuards(AuthGuard)
  @Delete(':id')
  async remove(@Param('id') id: string, @Req() req: any) {
    const idUsuario = parseInt(req.user.sub, 10);
    try {
      await this.dietaService.remove(+id, idUsuario);
      return { message: 'successfully removed' };
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.NOT_FOUND,
          error: error.message,
        },
        HttpStatus.NOT_FOUND,
        {
          cause: error,
        },
      );
    }
  }

  @UseGuards(AuthGuard)
  @Patch(':id')
  async update(
    @Param('id') id: string,
    @Body() data: DietaEditDTO,
    @Req() req: any,
  ) {
    const idUsuario = parseInt(req.user.sub, 10);
    try {
      return await this.dietaService.update(+id, data, idUsuario);
    } catch (error) {
      throw new HttpException(
        {
          status: HttpStatus.FORBIDDEN,
          error: error.message,
        },
        HttpStatus.FORBIDDEN,
        {
          cause: error,
        },
      );
    }
  }
}
