import { DietaController } from './dieta.controller';
import { DietaService } from './dieta.service';
import { Module } from '@nestjs/common';
import { PrismaService } from '../lib/prisma.service';

@Module({
  imports: [],
  controllers: [DietaController],
  providers: [DietaService, PrismaService],
  exports: [DietaService],
})
export class DietaModule {}
