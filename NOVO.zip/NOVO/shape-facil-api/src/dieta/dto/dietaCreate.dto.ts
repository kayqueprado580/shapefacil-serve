import { Dieta } from '../entities/dieta.entity';
import { IsNotEmpty, IsOptional } from 'class-validator';

export class DietaCreateDTO extends Dieta {
  @IsOptional()
  usuarioID?: number;
  @IsOptional()
  alunoID?: number;
  @IsOptional()
  nutricionistaID?: number;
  @IsNotEmpty()
  nome: string;
  @IsOptional()
  descricao?: string;
  @IsNotEmpty()
  tipo: string;
  @IsNotEmpty()
  periodo: string;
  @IsNotEmpty()
  json: string;
  @IsOptional()
  totalCalorias?: string;
  @IsOptional()
  totalProteinas?: string;
  @IsOptional()
  totalGordura?: string;
}
