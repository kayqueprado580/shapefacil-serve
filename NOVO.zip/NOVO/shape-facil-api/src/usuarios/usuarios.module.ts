import { UsuarioController } from './usuarios.controller';
import { UsuarioService } from './usuarios.service';
import { Module } from '@nestjs/common';
import { PrismaService } from '../lib/prisma.service';
import { PerfilService } from '../perfil/perfil.service';

@Module({
  imports: [],
  controllers: [UsuarioController],
  providers: [UsuarioService, PrismaService, PerfilService],
  exports: [UsuarioService],
})
export class UsuariosModule {}
