import { PerfilCreateDTO } from '../../perfil/dto/perfilCreate.dto';
import { UsuarioCreateDTO } from './usuarioCreate.dto';

export class CreateUserWithProfileDTO {
  usuario: UsuarioCreateDTO;
  perfilAcesso: PerfilCreateDTO;
}
