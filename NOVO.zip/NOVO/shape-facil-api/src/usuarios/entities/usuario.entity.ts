export class Usuario {
  id: number;
  uid: string;
  nome?: string;
  contato?: string;
  documento?: string;
  perfil: string;
  email: string;
  usuario: string;
  senha?: string;
  isAdmnistrador?: boolean;
  isNutricionista?: boolean;
  isTreinador?: boolean;
  isAluno?: boolean;
}
