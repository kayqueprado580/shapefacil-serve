import { Perfil } from './../perfil/entities/perfil.entity';
import {
  Injectable,
  BadRequestException,
  NotFoundException,
} from '@nestjs/common';
import * as bcrypt from 'bcrypt';
import { PrismaService } from '../lib/prisma.service';
import { Prisma } from '@prisma/client';
import { Usuario } from './entities/usuario.entity';
import { UsuarioCreateDTO } from './dto/usuarioCreate.dto';
import { checkIfExists } from '../util/database.utils';
import { UsuarioEditDTO } from './dto/usuarioEdit.dto';
import { hasChanged } from '../util/change-detector.utils';
import { PerfilService } from '../perfil/perfil.service';
import { PerfilCreateDTO } from '../perfil/dto/perfilCreate.dto';
import { CreateUserWithProfileDTO } from './dto/usrPerfilCreate.dto';

@Injectable()
export class UsuarioService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly perfilService: PerfilService,
  ) {}

  async findAll(skip: number, take: number, orderBy: string, id: number) {
    const users: Usuario[] = await this.prisma.usuario.findMany({
      skip: skip ? skip : 0,
      take: take ? take : 20,
      orderBy: {
        createdAt: orderBy
          ? orderBy.toLowerCase() === 'asc'
            ? 'asc'
            : 'desc'
          : 'desc',
      },
      where: {},
    });

    return {
      ...users,
      perfil_acesso: await this.findPerfil(id),
    };
  }

  async findOne(id: string) {
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: {
        uid: id,
      },
    });
    return {
      ...usuario,
      perfil_acesso: await this.findPerfil(usuario.id),
    };
  }

  async findOneByUser(usuario: string) {
    return await this.prisma.usuario.findUniqueOrThrow({
      where: {
        usuario,
      },
    });
  }

  async findPerfil(id: number) {
    return await this.prisma.perfilAcesso.findUniqueOrThrow({
      where: { usuarioID: id },
    });
  }

  async create(
    bodyDTO: CreateUserWithProfileDTO,
    idUsuario: number,
  ): Promise<CreateUserWithProfileDTO> {
    const usuarioDTO: UsuarioCreateDTO = bodyDTO.usuario;
    const perfilDTO: PerfilCreateDTO = bodyDTO.perfilAcesso;
    const emailExists = await checkIfExists(
      'usuario',
      'email',
      usuarioDTO.email,
    );
    if (emailExists)
      throw new BadRequestException('Já existe um usuário com este email.');

    const usernameExists = await checkIfExists(
      'usuario',
      'usuario',
      usuarioDTO.usuario,
    );
    if (usernameExists) throw new NotFoundException('Usuário já existe!');

    const hash = await bcrypt.hash(usuarioDTO.senha, 10);
    const data: Prisma.UsuarioCreateInput = {
      ...usuarioDTO,
      nome: usuarioDTO.nome.toLowerCase(),
      senha: hash,
    };
    const createdUser = await this.prisma.usuario.create({ data });
    const usuarioNovo = createdUser.id;

    if (!perfilDTO.acessoJson)
      throw new BadRequestException('Necessário o json de acesso');
    if (!perfilDTO.perfil) throw new BadRequestException('Inserir o perfil');

    const dataCreatePerfil = {
      ...perfilDTO,
      acessoJson: JSON.stringify(perfilDTO.acessoJson),
      usuarioID: usuarioNovo,
    };
    const createdPerfil = await this.perfilService.create(
      dataCreatePerfil,
      idUsuario,
    );

    return {
      usuario: { ...createdUser, senha: undefined },
      perfilAcesso: createdPerfil,
    };
  }

  async remove(id: number, idUsuarioLogado: number) {
    const usuario: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id },
    });

    const usuarioLogado: Usuario = await this.prisma.usuario.findUniqueOrThrow({
      where: { id: idUsuarioLogado },
    });

    if (usuarioLogado.perfil.toLocaleLowerCase() === 'administrador') {
      const perfil: Perfil[] = await this.perfilService.findAll(usuario.id, 0);
      await this.perfilService.remove(perfil[0].id);
    }
    return await this.prisma.usuario.delete({
      where: {
        id,
      },
    });
  }

  async update(id: number, userDTO: UsuarioEditDTO): Promise<Usuario> {
    const userBase = await this.prisma.usuario.findUniqueOrThrow({
      where: {
        id,
      },
    });

    const usernameHasChanged = hasChanged(userBase.usuario, userDTO.usuario);
    if (usernameHasChanged) {
      const usernameExists = await checkIfExists(
        'usuario',
        'usuario',
        userDTO.usuario,
      );
      if (usernameExists) throw new BadRequestException('Usuário já existe.');
    }

    const emailHasChanged = hasChanged(userBase.email, userDTO.email);
    if (emailHasChanged) {
      const emailExists = await checkIfExists(
        'usuario',
        'email',
        userDTO.email,
      );
      if (emailExists) {
        throw new BadRequestException('Já existe um usuário com este email.');
      }
    }

    if (!userDTO.nome) userDTO.nome = userBase.nome;
    if (!userDTO.contato) userDTO.contato = userBase.contato;
    if (!userDTO.documento) userDTO.documento = userBase.documento;
    if (!userDTO.perfil) userDTO.perfil = userBase.perfil;
    if (!userDTO.email) userDTO.email = userBase.email;
    if (!userDTO.usuario) userDTO.usuario = userBase.usuario;
    if (!userDTO.senha) userDTO.senha = userBase.senha;
    if (!userDTO.isAdmnistrador)
      userDTO.isAdmnistrador = userBase.isAdmnistrador;
    if (!userDTO.isNutricionista)
      userDTO.isNutricionista = userBase.isNutricionista;
    if (!userDTO.isAluno) userDTO.isAluno = userBase.isAluno;
    if (!userDTO.isTreinador) userDTO.isTreinador = userBase.isTreinador;

    const data: Prisma.UsuarioUpdateInput = {
      ...userDTO,
    };

    const updatedUser = await this.prisma.usuario.update({
      data,
      where: {
        id,
      },
    });

    return {
      ...updatedUser,
      senha: undefined,
    };
  }

  async updatePassword(id: number, userDTO: UsuarioEditDTO): Promise<Usuario> {
    const base = await this.prisma.usuario.findUniqueOrThrow({ where: { id } });
    const isPasswordSame = await this.comparePwd(userDTO.senha, base.senha);
    if (isPasswordSame)
      throw new BadRequestException(
        'Nova senha, igual a antiga. Por favor, troque de senha!',
      );

    const newPasswordHash = await bcrypt.hash(userDTO.senha, 10);
    const updatedUser = await this.prisma.usuario.update({
      where: { id },
      data: {
        senha: newPasswordHash,
      },
    });

    return {
      ...updatedUser,
      senha: undefined,
    };
  }

  async comparePwd(password: string, hash: string) {
    return await bcrypt.compare(password, hash);
  }
}
