export class Perfil {
  id: number;
  usuarioID?: number;
  perfil: string;
  acessoJson: string;
  createdAtUser?: number;
}
