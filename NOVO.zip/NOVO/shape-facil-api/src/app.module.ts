import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsuariosModule } from './usuarios/usuarios.module';
import { AuthModule } from './auth/auth.module';
import { AuthController } from './auth/auth.controller';
import { PerfilModule } from './perfil/perfil.module';
import { AuthService } from './auth/auth.service';
import { ConfigModule } from '@nestjs/config';
import { HistoricoModule } from './historicos/historico.module';
import { DietaModule } from './dieta/dieta.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    PerfilModule,
    UsuariosModule,
    AuthModule,
    HistoricoModule,
    DietaModule,
  ],
  controllers: [AppController, AuthController],
  providers: [AppService, AuthService],
  exports: [],
})
export class AppModule {}
