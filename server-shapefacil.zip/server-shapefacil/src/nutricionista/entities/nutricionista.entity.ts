export class Nutricionista {
  id?: number;
  usuarioId?: number;
  usrCriouId?: number;
  alunos?: string | string[];
}
