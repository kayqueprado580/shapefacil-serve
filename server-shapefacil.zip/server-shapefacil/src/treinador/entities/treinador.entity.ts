export class Treinador {
  id?: number;
  usuarioId?: number;
  usrCriouId?: number;
  alunos?: string | string[];
}
