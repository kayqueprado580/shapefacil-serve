export class Perfil {
  id: number;
  usuarioId?: number;
  perfil: string;
  acessoJson: string;
  createdAtUser?: number;
}
