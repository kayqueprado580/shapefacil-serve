export class Aluno {
  id?: number;
  usuarioId?: number;
  treinadorId?: number;
  nutricionistaId?: number;
  usrCriouId?: number;
  peso?: string;
  altura?: string;
  porcGordura?: string;
  porcMassaMagra?: string;
  medidas?: string;
  dataAvaliacao?: Date;
}
