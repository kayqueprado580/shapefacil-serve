export class HistoricoAluno {
  id?: number;
  alunoId?: number;
  treinadorId?: number;
  nutricionistaId?: number;
  peso?: string;
  altura?: string;
  porcGordura?: string;
  porcMassaMagra?: string;
  medidas?: string;
  dataAvaliacao?: Date;
}
