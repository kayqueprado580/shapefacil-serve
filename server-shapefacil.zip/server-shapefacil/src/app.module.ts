import { NutricionistaModule } from './nutricionista/nutricionista.module';
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UsuariosModule } from './usuarios/usuarios.module';
import { AuthModule } from './auth/auth.module';
import { AuthController } from './auth/auth.controller';
import { PerfilModule } from './perfil/perfil.module';
import { AuthService } from './auth/auth.service';
import { TreinadorModule } from './treinador/treinador.module';
import { AlunoModule } from './aluno/aluno.module';

@Module({
  imports: [
    ConfigModule.forRoot(),
    PerfilModule,
    UsuariosModule,
    NutricionistaModule,
    AuthModule,
    TreinadorModule,
    AlunoModule,
  ],
  controllers: [AppController, AuthController],
  providers: [AppService, AuthService],
  exports: [],
})
export class AppModule {}
