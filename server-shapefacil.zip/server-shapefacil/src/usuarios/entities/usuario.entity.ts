export class Usuario {
  id: number;
  nome: string;
  uid: string;
  contato?: string;
  documento?: string;
  perfil: string;
  email: string;
  usuario: string;
  senha?: string;
}
