-- DropIndex
DROP INDEX "perfil_acesso_createdAtUser_key";
