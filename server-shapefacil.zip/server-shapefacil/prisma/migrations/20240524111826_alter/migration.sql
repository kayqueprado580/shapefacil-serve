/*
  Warnings:

  - A unique constraint covering the columns `[uid]` on the table `usuario` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "usuario_uid_key" ON "usuario"("uid");
