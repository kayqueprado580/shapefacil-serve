-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_treinador" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "usrCriouId" INTEGER,
    "alunos" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "treinador_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_treinador" ("alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId") SELECT "alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId" FROM "treinador";
DROP TABLE "treinador";
ALTER TABLE "new_treinador" RENAME TO "treinador";
CREATE UNIQUE INDEX "treinador_usuarioId_key" ON "treinador"("usuarioId");
PRAGMA foreign_key_check("treinador");
PRAGMA foreign_keys=ON;
