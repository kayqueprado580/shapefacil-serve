-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_historico_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "alunoId" INTEGER NOT NULL,
    "treinadorId" INTEGER NOT NULL,
    "nutricionistaId" INTEGER NOT NULL,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "historico_aluno_alunoId_fkey" FOREIGN KEY ("alunoId") REFERENCES "aluno" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "historico_aluno_treinadorId_fkey" FOREIGN KEY ("treinadorId") REFERENCES "treinador" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "historico_aluno_nutricionistaId_fkey" FOREIGN KEY ("nutricionistaId") REFERENCES "nutricionista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_historico_aluno" ("altura", "alunoId", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt") SELECT "altura", "alunoId", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt" FROM "historico_aluno";
DROP TABLE "historico_aluno";
ALTER TABLE "new_historico_aluno" RENAME TO "historico_aluno";
PRAGMA foreign_key_check("historico_aluno");
PRAGMA foreign_keys=ON;
