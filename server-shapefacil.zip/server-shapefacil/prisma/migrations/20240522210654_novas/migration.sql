-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_nutricionista" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "usrCriouId" INTEGER,
    "alunos" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "nutricionista_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_nutricionista" ("alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId") SELECT "alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId" FROM "nutricionista";
DROP TABLE "nutricionista";
ALTER TABLE "new_nutricionista" RENAME TO "nutricionista";
CREATE UNIQUE INDEX "nutricionista_usuarioId_key" ON "nutricionista"("usuarioId");
PRAGMA foreign_key_check("nutricionista");
PRAGMA foreign_keys=ON;
