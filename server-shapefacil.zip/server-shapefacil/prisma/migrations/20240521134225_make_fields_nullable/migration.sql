/*
  Warnings:

  - You are about to drop the column `alunosJson` on the `historico_aluno` table. All the data in the column will be lost.
  - You are about to drop the column `alunosJson` on the `aluno` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_especialista" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "usrCriouId" INTEGER NOT NULL,
    "tipo" TEXT NOT NULL,
    "alunosJson" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "especialista_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_especialista" ("alunosJson", "createdAt", "id", "tipo", "updatedAt", "usrCriouId", "usuarioId") SELECT "alunosJson", "createdAt", "id", "tipo", "updatedAt", "usrCriouId", "usuarioId" FROM "especialista";
DROP TABLE "especialista";
ALTER TABLE "new_especialista" RENAME TO "especialista";
CREATE TABLE "new_historico_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "alunoId" INTEGER NOT NULL,
    "especialistaId" INTEGER NOT NULL,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "historico_aluno_alunoId_fkey" FOREIGN KEY ("alunoId") REFERENCES "aluno" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "historico_aluno_especialistaId_fkey" FOREIGN KEY ("especialistaId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_historico_aluno" ("altura", "alunoId", "createdAt", "dataAvaliacao", "especialistaId", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt") SELECT "altura", "alunoId", "createdAt", "dataAvaliacao", "especialistaId", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt" FROM "historico_aluno";
DROP TABLE "historico_aluno";
ALTER TABLE "new_historico_aluno" RENAME TO "historico_aluno";
CREATE TABLE "new_dieta" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "alunoId" INTEGER NOT NULL,
    "especialistaId" INTEGER NOT NULL,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "periodo" TEXT NOT NULL,
    "refeicoesJson" TEXT NOT NULL,
    "totalCalorias" TEXT,
    "totalProteinas" TEXT,
    "totalGordura" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "dieta_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "dieta_alunoId_fkey" FOREIGN KEY ("alunoId") REFERENCES "aluno" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "dieta_especialistaId_fkey" FOREIGN KEY ("especialistaId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_dieta" ("alunoId", "createdAt", "descricao", "especialistaId", "id", "nome", "periodo", "refeicoesJson", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioId") SELECT "alunoId", "createdAt", "descricao", "especialistaId", "id", "nome", "periodo", "refeicoesJson", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioId" FROM "dieta";
DROP TABLE "dieta";
ALTER TABLE "new_dieta" RENAME TO "dieta";
CREATE TABLE "new_treino" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "alunoId" INTEGER NOT NULL,
    "especialistaId" INTEGER NOT NULL,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "PeriodoTreino" TEXT NOT NULL,
    "exerciciosJson" TEXT NOT NULL,
    "intensidade" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "treino_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "treino_alunoId_fkey" FOREIGN KEY ("alunoId") REFERENCES "aluno" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "treino_especialistaId_fkey" FOREIGN KEY ("especialistaId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_treino" ("PeriodoTreino", "alunoId", "createdAt", "descricao", "especialistaId", "exerciciosJson", "id", "intensidade", "nome", "tipo", "updatedAt", "usuarioId") SELECT "PeriodoTreino", "alunoId", "createdAt", "descricao", "especialistaId", "exerciciosJson", "id", "intensidade", "nome", "tipo", "updatedAt", "usuarioId" FROM "treino";
DROP TABLE "treino";
ALTER TABLE "new_treino" RENAME TO "treino";
CREATE TABLE "new_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "especialistaId" INTEGER NOT NULL,
    "usrCriouId" INTEGER NOT NULL,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "aluno_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "aluno_especialistaId_fkey" FOREIGN KEY ("especialistaId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_aluno" ("altura", "createdAt", "dataAvaliacao", "especialistaId", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt", "usrCriouId", "usuarioId") SELECT "altura", "createdAt", "dataAvaliacao", "especialistaId", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt", "usrCriouId", "usuarioId" FROM "aluno";
DROP TABLE "aluno";
ALTER TABLE "new_aluno" RENAME TO "aluno";
CREATE TABLE "new_usuario" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "uid" TEXT NOT NULL,
    "nome" TEXT,
    "contato" TEXT,
    "documento" TEXT,
    "perfil" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "usuario" TEXT NOT NULL,
    "senha" TEXT NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_usuario" ("contato", "createdAt", "documento", "email", "id", "nome", "perfil", "senha", "uid", "updatedAt", "usuario") SELECT "contato", "createdAt", "documento", "email", "id", "nome", "perfil", "senha", "uid", "updatedAt", "usuario" FROM "usuario";
DROP TABLE "usuario";
ALTER TABLE "new_usuario" RENAME TO "usuario";
CREATE UNIQUE INDEX "usuario_email_key" ON "usuario"("email");
CREATE UNIQUE INDEX "usuario_usuario_key" ON "usuario"("usuario");
CREATE TABLE "new_avaliacao" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "alunoId" INTEGER NOT NULL,
    "especialistaId" INTEGER NOT NULL,
    "dietaId" INTEGER NOT NULL,
    "treinoId" INTEGER NOT NULL,
    "nome" TEXT,
    "tipo" TEXT NOT NULL,
    "nota" INTEGER NOT NULL,
    "descricao" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "avaliacao_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "avaliacao_alunoId_fkey" FOREIGN KEY ("alunoId") REFERENCES "aluno" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "avaliacao_especialistaId_fkey" FOREIGN KEY ("especialistaId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "avaliacao_dietaId_fkey" FOREIGN KEY ("dietaId") REFERENCES "dieta" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "avaliacao_treinoId_fkey" FOREIGN KEY ("treinoId") REFERENCES "treino" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_avaliacao" ("alunoId", "createdAt", "descricao", "dietaId", "especialistaId", "id", "nome", "nota", "tipo", "treinoId", "updatedAt", "usuarioId") SELECT "alunoId", "createdAt", "descricao", "dietaId", "especialistaId", "id", "nome", "nota", "tipo", "treinoId", "updatedAt", "usuarioId" FROM "avaliacao";
DROP TABLE "avaliacao";
ALTER TABLE "new_avaliacao" RENAME TO "avaliacao";
PRAGMA foreign_key_check("especialista");
PRAGMA foreign_key_check("historico_aluno");
PRAGMA foreign_key_check("dieta");
PRAGMA foreign_key_check("treino");
PRAGMA foreign_key_check("aluno");
PRAGMA foreign_key_check("usuario");
PRAGMA foreign_key_check("avaliacao");
PRAGMA foreign_keys=ON;
