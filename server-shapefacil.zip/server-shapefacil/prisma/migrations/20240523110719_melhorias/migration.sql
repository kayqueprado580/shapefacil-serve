-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "treinadorId" INTEGER NOT NULL,
    "nutricionistaId" INTEGER NOT NULL,
    "usrCriouId" INTEGER NOT NULL,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "aluno_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "aluno_treinadorId_fkey" FOREIGN KEY ("treinadorId") REFERENCES "treinador" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "aluno_nutricionistaId_fkey" FOREIGN KEY ("nutricionistaId") REFERENCES "nutricionista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_aluno" ("altura", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt", "usrCriouId", "usuarioId") SELECT "altura", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt", "usrCriouId", "usuarioId" FROM "aluno";
DROP TABLE "aluno";
ALTER TABLE "new_aluno" RENAME TO "aluno";
CREATE UNIQUE INDEX "aluno_usuarioId_key" ON "aluno"("usuarioId");
PRAGMA foreign_key_check("aluno");
PRAGMA foreign_keys=ON;
