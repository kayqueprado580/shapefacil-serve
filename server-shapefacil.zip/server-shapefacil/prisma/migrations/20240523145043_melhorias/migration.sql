-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_dieta" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "alunoId" INTEGER,
    "nutricionistaId" INTEGER,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "periodo" TEXT NOT NULL,
    "refeicoesJson" TEXT NOT NULL,
    "totalCalorias" TEXT,
    "totalProteinas" TEXT,
    "totalGordura" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_dieta" ("alunoId", "createdAt", "descricao", "id", "nome", "nutricionistaId", "periodo", "refeicoesJson", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioId") SELECT "alunoId", "createdAt", "descricao", "id", "nome", "nutricionistaId", "periodo", "refeicoesJson", "tipo", "totalCalorias", "totalGordura", "totalProteinas", "updatedAt", "usuarioId" FROM "dieta";
DROP TABLE "dieta";
ALTER TABLE "new_dieta" RENAME TO "dieta";
CREATE TABLE "new_treinador" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "usrCriouId" INTEGER,
    "alunos" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_treinador" ("alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId") SELECT "alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId" FROM "treinador";
DROP TABLE "treinador";
ALTER TABLE "new_treinador" RENAME TO "treinador";
CREATE UNIQUE INDEX "treinador_usuarioId_key" ON "treinador"("usuarioId");
CREATE TABLE "new_avaliacao" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "alunoId" INTEGER,
    "treinadorId" INTEGER,
    "nutricionistaId" INTEGER,
    "dietaId" INTEGER,
    "treinoId" INTEGER,
    "nome" TEXT,
    "tipo" TEXT NOT NULL,
    "nota" INTEGER NOT NULL,
    "descricao" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_avaliacao" ("alunoId", "createdAt", "descricao", "dietaId", "id", "nome", "nota", "nutricionistaId", "tipo", "treinadorId", "treinoId", "updatedAt", "usuarioId") SELECT "alunoId", "createdAt", "descricao", "dietaId", "id", "nome", "nota", "nutricionistaId", "tipo", "treinadorId", "treinoId", "updatedAt", "usuarioId" FROM "avaliacao";
DROP TABLE "avaliacao";
ALTER TABLE "new_avaliacao" RENAME TO "avaliacao";
CREATE TABLE "new_treino" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "alunoId" INTEGER,
    "treinadorId" INTEGER,
    "nome" TEXT NOT NULL,
    "descricao" TEXT,
    "tipo" TEXT NOT NULL,
    "PeriodoTreino" TEXT NOT NULL,
    "exerciciosJson" TEXT NOT NULL,
    "intensidade" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_treino" ("PeriodoTreino", "alunoId", "createdAt", "descricao", "exerciciosJson", "id", "intensidade", "nome", "tipo", "treinadorId", "updatedAt", "usuarioId") SELECT "PeriodoTreino", "alunoId", "createdAt", "descricao", "exerciciosJson", "id", "intensidade", "nome", "tipo", "treinadorId", "updatedAt", "usuarioId" FROM "treino";
DROP TABLE "treino";
ALTER TABLE "new_treino" RENAME TO "treino";
CREATE TABLE "new_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "treinadorId" INTEGER,
    "nutricionistaId" INTEGER,
    "usrCriouId" INTEGER,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_aluno" ("altura", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt", "usrCriouId", "usuarioId") SELECT "altura", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt", "usrCriouId", "usuarioId" FROM "aluno";
DROP TABLE "aluno";
ALTER TABLE "new_aluno" RENAME TO "aluno";
CREATE UNIQUE INDEX "aluno_usuarioId_key" ON "aluno"("usuarioId");
CREATE TABLE "new_nutricionista" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER,
    "usrCriouId" INTEGER,
    "alunos" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_nutricionista" ("alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId") SELECT "alunos", "createdAt", "id", "updatedAt", "usrCriouId", "usuarioId" FROM "nutricionista";
DROP TABLE "nutricionista";
ALTER TABLE "new_nutricionista" RENAME TO "nutricionista";
CREATE UNIQUE INDEX "nutricionista_usuarioId_key" ON "nutricionista"("usuarioId");
CREATE TABLE "new_historico_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "alunoId" INTEGER,
    "treinadorId" INTEGER,
    "nutricionistaId" INTEGER,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL
);
INSERT INTO "new_historico_aluno" ("altura", "alunoId", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt") SELECT "altura", "alunoId", "createdAt", "dataAvaliacao", "id", "medidas", "nutricionistaId", "peso", "porcGordura", "porcMassaMagra", "treinadorId", "updatedAt" FROM "historico_aluno";
DROP TABLE "historico_aluno";
ALTER TABLE "new_historico_aluno" RENAME TO "historico_aluno";
PRAGMA foreign_key_check("dieta");
PRAGMA foreign_key_check("treinador");
PRAGMA foreign_key_check("avaliacao");
PRAGMA foreign_key_check("treino");
PRAGMA foreign_key_check("aluno");
PRAGMA foreign_key_check("nutricionista");
PRAGMA foreign_key_check("historico_aluno");
PRAGMA foreign_keys=ON;
