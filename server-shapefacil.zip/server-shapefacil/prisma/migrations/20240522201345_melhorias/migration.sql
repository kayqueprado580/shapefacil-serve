/*
  Warnings:

  - You are about to drop the column `especialistaId` on the `aluno` table. All the data in the column will be lost.
  - You are about to drop the column `alunosJson` on the `especialista` table. All the data in the column will be lost.
  - Added the required column `especialistaNutricionistaId` to the `aluno` table without a default value. This is not possible if the table is not empty.
  - Added the required column `especialistaTreinadorId` to the `aluno` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_aluno" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "especialistaTreinadorId" INTEGER NOT NULL,
    "especialistaNutricionistaId" INTEGER NOT NULL,
    "usrCriouId" INTEGER NOT NULL,
    "peso" TEXT,
    "altura" TEXT,
    "porcGordura" TEXT,
    "porcMassaMagra" TEXT,
    "medidas" TEXT,
    "dataAvaliacao" DATETIME NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "aluno_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT "aluno_especialistaTreinadorId_fkey" FOREIGN KEY ("especialistaTreinadorId") REFERENCES "especialista" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_aluno" ("altura", "createdAt", "dataAvaliacao", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt", "usrCriouId", "usuarioId") SELECT "altura", "createdAt", "dataAvaliacao", "id", "medidas", "peso", "porcGordura", "porcMassaMagra", "updatedAt", "usrCriouId", "usuarioId" FROM "aluno";
DROP TABLE "aluno";
ALTER TABLE "new_aluno" RENAME TO "aluno";
CREATE UNIQUE INDEX "aluno_usuarioId_key" ON "aluno"("usuarioId");
CREATE TABLE "new_especialista" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "usrCriouId" INTEGER NOT NULL,
    "tipo" TEXT NOT NULL,
    "alunos" TEXT,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "especialista_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_especialista" ("createdAt", "id", "tipo", "updatedAt", "usrCriouId", "usuarioId") SELECT "createdAt", "id", "tipo", "updatedAt", "usrCriouId", "usuarioId" FROM "especialista";
DROP TABLE "especialista";
ALTER TABLE "new_especialista" RENAME TO "especialista";
CREATE UNIQUE INDEX "especialista_usuarioId_key" ON "especialista"("usuarioId");
PRAGMA foreign_key_check("aluno");
PRAGMA foreign_key_check("especialista");
PRAGMA foreign_keys=ON;
