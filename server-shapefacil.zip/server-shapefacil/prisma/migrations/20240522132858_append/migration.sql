/*
  Warnings:

  - Added the required column `createdAtUser` to the `perfil_acesso` table without a default value. This is not possible if the table is not empty.

*/
-- RedefineTables
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_perfil_acesso" (
    "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
    "usuarioId" INTEGER NOT NULL,
    "perfil" TEXT NOT NULL,
    "acessoJson" TEXT NOT NULL,
    "createdAtUser" INTEGER NOT NULL,
    "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" DATETIME NOT NULL,
    CONSTRAINT "perfil_acesso_usuarioId_fkey" FOREIGN KEY ("usuarioId") REFERENCES "usuario" ("id") ON DELETE RESTRICT ON UPDATE CASCADE
);
INSERT INTO "new_perfil_acesso" ("acessoJson", "createdAt", "id", "perfil", "updatedAt", "usuarioId") SELECT "acessoJson", "createdAt", "id", "perfil", "updatedAt", "usuarioId" FROM "perfil_acesso";
DROP TABLE "perfil_acesso";
ALTER TABLE "new_perfil_acesso" RENAME TO "perfil_acesso";
CREATE UNIQUE INDEX "perfil_acesso_usuarioId_key" ON "perfil_acesso"("usuarioId");
CREATE UNIQUE INDEX "perfil_acesso_createdAtUser_key" ON "perfil_acesso"("createdAtUser");
PRAGMA foreign_key_check("perfil_acesso");
PRAGMA foreign_keys=ON;
