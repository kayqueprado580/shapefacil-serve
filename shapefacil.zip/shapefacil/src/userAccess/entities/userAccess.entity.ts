export class UserAccess {
  id: number;
  uid: string;
  name: string;
  access: string;
  userId?: number;
}
