export class Usuario {
  nome: string;
  contato?: string;
  documento?: string;
  perfil: string;
  email: string;
  usuario: string;
  senha: string;
}
